package Vista;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PGNLoader {
    public static List<String> cargarArchivoPGN(File archivoSeleccionado) {
        List<String> movimientos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivoSeleccionado))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.startsWith("[") && !linea.trim().isEmpty()) {
                    String[] parts = linea.split(" ");
                    for (String part : parts) {
                        if (part.matches("^[a-h1-8NBRQK]+$") || part.matches("O-O(?:-O)?")) {
                            movimientos.add(part);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Movimientos cargados: " + movimientos);
        return movimientos;
    }
}
