package Vista;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Color;


public class AjedrezGUI extends JPanel {
    private Tablero tablero;
    private MovimientosAjedrez movimientosAjedrez;

    public AjedrezGUI(Tablero tablero) {
        this.tablero = tablero;
        this.movimientosAjedrez = new MovimientosAjedrez(tablero); // Inicializamos con el tablero
        inicializarGUI();
    }

    private void inicializarGUI() {
        setLayout(new GridLayout(8, 8)); // 8x8 para el tablero de ajedrez
        actualizarTablero(); // Inicializamos el tablero al inicio
    }

    // Método para actualizar el tablero visualmente
    public void actualizarTablero() {
        removeAll(); // Limpia el panel actual
        String[][] estadoTablero = tablero.getTablero(); // Obtén el estado actual del tablero

        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                String pieza = estadoTablero[fila][col];
                JButton boton = new JButton();

                if (pieza != null && !pieza.isEmpty()) {
                    boton.setText(String.valueOf(pieza.charAt(0)));  // Solo muestra la inicial de la pieza
                } else {
                    boton.setText(""); // Casilla vacía
                }

                // Establecer el color de fondo de la casilla
                if ((fila + col) % 2 == 0) {
                    boton.setBackground(Color.WHITE);
                } else {
                    boton.setBackground(Color.PINK);
                }

                add(boton); // Añadir el botón al panel del tablero
            }
        }

        revalidate(); // Revalidate the layout
        repaint();    // Repaint the panel to reflect the changes
    }
}
