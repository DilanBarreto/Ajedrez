package Vista;

public class Tablero {
    private String[][] tablero;

    public Tablero() {
        tablero = new String[8][8];
        inicializarTablero();
    }

    // Método para inicializar el tablero con la posición inicial de las piezas
    private void inicializarTablero() {
        tablero[0] = new String[]{"R", "N", "B", "Q", "K", "B", "N", "R"};
        tablero[1] = new String[]{"P", "P", "P", "P", "P", "P", "P", "P"};
        for (int i = 2; i < 6; i++) {
            for (int j = 0; j < 8; j++) {
                tablero[i][j] = ""; // Casillas vacías
            }
        }
        tablero[6] = new String[]{"p", "p", "p", "p", "p", "p", "p", "p"};
        tablero[7] = new String[]{"r", "n", "b", "q", "k", "b", "n", "r"};
    }

    // Método público para resetear el tablero a su posición inicial
    public void resetearTablero() {
        inicializarTablero();
    }

    // Devuelve el estado actual del tablero
    public String[][] getTablero() {
        return tablero;
    }

    // Mueve una pieza de una posición a otra en el tablero
    public void moverPieza(int filaInicial, int columnaInicial, int filaDestino, int columnaDestino) {
        if (!posicionValida(filaInicial, columnaInicial) || !posicionValida(filaDestino, columnaDestino)) {
            System.out.println("Movimiento inválido.");
            return;
        }
        if (tablero[filaInicial][columnaInicial] == null || tablero[filaInicial][columnaInicial].isEmpty()) {
            System.out.println("No hay pieza en la posición inicial.");
            return;
        }
        tablero[filaDestino][columnaDestino] = tablero[filaInicial][columnaInicial];
        tablero[filaInicial][columnaInicial] = ""; // Vacía la casilla original
    }

    // Verifica si una posición está dentro de los límites del tablero
    public boolean posicionValida(int fila, int columna) {
        return fila >= 0 && fila < 8 && columna >= 0 && columna < 8;
    }
}
