package Vista;

import Controlador.InterpreteMovimiento;

import java.io.File;
import java.util.List;

public class MovimientosAjedrez {
    private InterpreteMovimiento interprete;
    private Tablero tablero;

    public MovimientosAjedrez(Tablero tablero) {
        this.tablero = tablero;
        this.interprete = new InterpreteMovimiento(tablero);
    }

    // Método para cargar y aplicar movimientos desde un archivo PGN
    public void aplicarMovimientosDesdeArchivo(File archivoSeleccionado) {
        if (archivoSeleccionado == null || !archivoSeleccionado.exists()) {
            System.out.println("El archivo seleccionado no es válido.");
            return;
        }

        // Resetear el tablero a su posición inicial
        tablero.resetearTablero();
        System.out.println("Vista.Tablero reseteado a la posición inicial.");

        // Cargar movimientos desde un archivo PGN
        List<String> movimientos = PGNLoader.cargarArchivoPGN(archivoSeleccionado);

        if (movimientos == null || movimientos.isEmpty()) {
            System.out.println("No se pudieron cargar movimientos del archivo o el archivo está vacío.");
            return;
        }

        // Aplicar los movimientos al tablero
        aplicarMovimientos(movimientos);
    }

    // Método auxiliar para aplicar una lista de movimientos al tablero
    private void aplicarMovimientos(List<String> movimientos) {
        for (String movimiento : movimientos) {
            System.out.println("Aplicando movimiento: " + movimiento);
            try {
                // Suponiendo que `interprete.ejecutarMovimiento()` lanza excepciones en caso de error
                interprete.ejecutarMovimiento(movimiento);
            } catch (Exception e) {
                System.out.println("Error al aplicar el movimiento " + movimiento + ": " + e.getMessage());
            }
        }
    }
}
