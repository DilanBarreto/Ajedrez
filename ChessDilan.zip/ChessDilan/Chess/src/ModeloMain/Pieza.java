package ModeloMain;

// Clase base abstracta para todas las piezas
public abstract class Pieza {
    private boolean esBlanca;

    public Pieza(boolean esBlanca) {
        this.esBlanca = esBlanca;
    }

    public boolean esBlanca() {
        return esBlanca;
    }

    // Método getColor para devolver "Blanco" o "Negro"
    public String getColor() {
        return esBlanca ? "Blanco" : "Negro";
    }

    // Método getTipo para devolver el tipo de pieza según su clase
    public String getTipo() {
        return getClass().getSimpleName(); // Retorna el nombre de la clase como tipo
    }

    public abstract boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero);

    @Override
    public abstract String toString(); // Será implementado por cada subclase
}

// Clase Modelo.Rey
class Rey extends Pieza {
    public Rey(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        // Movimiento: una casilla en cualquier dirección
        return Math.abs(startX - endX) <= 1 && Math.abs(startY - endY) <= 1;
    }

    @Override
    public String toString() {
        return esBlanca() ? "K" : "k";
    }
}

// Clase Modelo.Reina
class Reina extends Pieza {
    public Reina(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        // La reina se mueve como una torre o como un alfil
        return new Torre(esBlanca()).movimientoValido(startX, startY, endX, endY, tablero) ||
                new Alfil(esBlanca()).movimientoValido(startX, startY, endX, endY, tablero);
    }

    @Override
    public String toString() {
        return esBlanca() ? "Q" : "q";
    }
}

// Clase Modelo.Torre
class Torre extends Pieza {
    public Torre(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        // Movimiento en línea recta horizontal o vertical
        if (startX != endX && startY != endY) return false;

        int stepX = Integer.compare(endX, startX);
        int stepY = Integer.compare(endY, startY);

        // Verifica si hay piezas en el camino
        for (int x = startX + stepX, y = startY + stepY; x != endX || y != endY; x += stepX, y += stepY) {
            if (tablero[x][y] != null) return false; // Hay una pieza en el camino
        }
        return true;
    }

    @Override
    public String toString() {
        return esBlanca() ? "T" : "t";
    }
}

// Clase Modelo.Alfil
class Alfil extends Pieza {
    public Alfil(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        // Verificar si el movimiento es en diagonal
        if (Math.abs(startX - endX) != Math.abs(startY - endY)) return false;

        int stepX = Integer.compare(endX, startX); // Determina la dirección en X
        int stepY = Integer.compare(endY, startY); // Determina la dirección en Y

        int x = startX + stepX;
        int y = startY + stepY;

        // Recorrer la ruta en diagonal y verificar si hay alguna pieza en el camino
        while (x != endX && y != endY) {
            if (tablero[x][y] != null) return false; // Hay una pieza en el camino
            x += stepX;
            y += stepY;
        }

        // Validar posición final
        return tablero[endX][endY] == null || tablero[endX][endY].esBlanca() != this.esBlanca();
    }

    @Override
    public String toString() {
        return esBlanca() ? "B" : "b";
    }
}

// Clase Modelo.Caballo
class Caballo extends Pieza {
    public Caballo(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        int dx = Math.abs(startX - endX);
        int dy = Math.abs(startY - endY);
        // Movimiento en forma de "L"
        return (dx == 2 && dy == 1) || (dx == 1 && dy == 2);
    }

    @Override
    public String toString() {
        return esBlanca() ? "C" : "c";
    }
}

// Clase Modelo.Peón
class Peón extends Pieza {
    public Peón(boolean esBlanca) {
        super(esBlanca);
    }

    @Override
    public boolean movimientoValido(int startX, int startY, int endX, int endY, Pieza[][] tablero) {
        int direction = esBlanca() ? -1 : 1; // Arriba para blanco, abajo para negro

        if (startY == endY) { // Movimiento hacia adelante
            if (endX == startX + direction && tablero[endX][endY] == null) return true;
            if ((startX == 6 && esBlanca() || startX == 1 && !esBlanca()) && endX == startX + 2 * direction && tablero[endX][endY] == null) return true;
        } else if (Math.abs(startY - endY) == 1 && endX == startX + direction) { // Captura en diagonal
            return tablero[endX][endY] != null && tablero[endX][endY].esBlanca() != esBlanca();
        }
        return false;
    }

    @Override
    public String toString() {
        return esBlanca() ? "P" : "p";
    }
}
