package ModeloMain;

import Vista.AjedrezGUI;
import Vista.MovimientosAjedrez;
import Vista.Tablero;

import javax.swing.*;
import java.io.File;

public class Main {
    public static void main(String[] args) {

        Tablero tablero = new Tablero();
        AjedrezGUI gui = new AjedrezGUI(tablero);
        JFrame frame = new JFrame("Ajedrez");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(gui);
        frame.setSize(800, 800);
        frame.setVisible(true);

        MovimientosAjedrez movimientosAjedrez = new MovimientosAjedrez(tablero);

        cargarArchivoPGN(movimientosAjedrez, gui);
    }

    // Método para mostrar el cuadro de diálogo y cargar el archivo PGN
    private static void cargarArchivoPGN(MovimientosAjedrez movimientosAjedrez, AjedrezGUI gui) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecciona un archivo PGN");

        int resultado = fileChooser.showOpenDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + archivoSeleccionado.getName());

            movimientosAjedrez.aplicarMovimientosDesdeArchivo(archivoSeleccionado);
            gui.actualizarTablero();
        } else {
            System.out.println("No se seleccionó ningún archivo.");
        }
    }
}
