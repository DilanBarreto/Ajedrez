package ModeloMain;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LecturaRutas {
    private List<String> rutas;

    public LecturaRutas(String rutaArchivo) {
        rutas = new ArrayList<>();
        leerArchivo(rutaArchivo);
    }

    private void leerArchivo(String rutaArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                rutas.add(linea);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String> getRutas() {
        return rutas;
    }

    public static void main(String[] args) {
        LecturaRutas lecturaRutas = new LecturaRutas("src/rutas_pgn.txt");
        List<String> rutas = lecturaRutas.getRutas();
        for (String ruta : rutas) {
            System.out.println(ruta);
        }
    }
}
