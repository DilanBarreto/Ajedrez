package Controlador;

import Vista.Tablero;

public class InterpreteMovimiento {
    private Tablero tablero;

    public InterpreteMovimiento(Tablero tablero) {
        extracted(tablero);
    }

    private void extracted(Tablero tablero) {
        this.tablero = tablero;
    }

    public <Tablero> InterpreteMovimiento(Tablero tablero) {

    }

    public void ejecutarMovimiento(String movimiento) {
        if (movimiento.equals("O-O")) {
            // Enroque corto
            tablero.moverPieza(7, 4, 7, 6); // Posición del rey
            tablero.moverPieza(7, 7, 7, 5); // Posición de la torre
        } else if (movimiento.equals("O-O-O")) {
            // Enroque largo
            tablero.moverPieza(7, 4, 7, 2); // Posición del rey
            tablero.moverPieza(7, 0, 7, 3); // Posición de la torre
        } else {
            interpretarMovimientoPieza(movimiento);
        }
    }

    private void interpretarMovimientoPieza(String movimiento) {
        int columnaDestino = movimiento.charAt(movimiento.length() - 2) - 'a';
        int filaDestino = 8 - Character.getNumericValue(movimiento.charAt(movimiento.length() - 1));

    }
}