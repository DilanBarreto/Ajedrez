package Controlador;

import Vista.AjedrezGUI;
import Vista.Tablero;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PGNPlayer {
    private Tablero tablero;
    private AjedrezGUI gui;

    public PGNPlayer(Tablero tablero, AjedrezGUI gui) {
        this.tablero = tablero;
        this.gui = gui;
    }

    public void cargarYEjecutarPGN(String rutaArchivo) {
        List<String> movimientos = leerMovimientosPGN(rutaArchivo);
        ejecutarMovimientosPGN(movimientos);
    }

    private List<String> leerMovimientosPGN(String rutaArchivo) {
        List<String> movimientos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (!linea.startsWith("[")) {
                    String[] movimientosLinea = linea.split(" ");
                    for (String movimiento : movimientosLinea) {
                        if (!movimiento.isEmpty()) {
                            movimientos.add(movimiento);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return movimientos;
    }

    private void ejecutarMovimientosPGN(List<String> movimientos) {
        InterpreteMovimiento interprete = new InterpreteMovimiento(tablero);
        for (String movimiento : movimientos) {
            interprete.ejecutarMovimiento(movimiento);
            gui.actualizarTablero();
            try {
                Thread.sleep(1000); // Pausa de 1 segundo entre movimientos
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}